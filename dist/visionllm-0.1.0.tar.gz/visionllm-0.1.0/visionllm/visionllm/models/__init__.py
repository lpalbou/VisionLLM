"""
Models subpackage for VisionLLM.

This package contains modules for different vision model integrations.
""" 